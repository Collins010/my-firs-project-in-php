<style>
    body {
        font-family: Arial, sans-serif;
        background-image: url("ww.jpg");
    }
    @media screen and (max-width: 768px) {
        body {
            font-size: 14px;
        }
    }

    @media screen and (max-width: 480px) {
        body {
            font-size: 12px;
        }
    }

    .citizen-dashboard {
        display: flex;
        margin: 50px auto;
        max-width: 1200px;
    }

    .menu {
        width: 200px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        padding: 20px;
    }

    .menu ul {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .menu li {
        margin-bottom: 10px;
    }

    .menu a {
        display: block;
        padding: 10px;
        color: #555;
        text-decoration: none;
    }

    .menu a:hover {
        background-color: #f2f2f2;
    }

    .content {
        flex: 1;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        padding: 20px;
    }

    h2 {
        margin-top: 0;
        margin-bottom: 20px;
    }
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Citizen Dashboard</title>
    <!--<link rel="stylesheet" type="text/css" href="style.css"> -->
</head>
<body>
<div class="citizen-dashboard">
    <div class="menu">
        <ul>
            <li><a href="addComplain.php">Add Complaint</a></li>
            <li><a href="viewComplain.php">View Complaints</a></li>
            <li><a href="login.html">LOGOUT</a> </li>
        </ul>
    </div>
    <div class="content">
        <h2>Citizen Dashboard</h2>
        <!-- Add content here -->
    </div>
</div>
</body>
</html>