<?php
// Connect to the database
require_once 'db_connection.php';

// Check if the form has been submitted
if (isset($_POST['submit'])) {
    // Get the ID of the report to update
    $id = $_POST['id'];

    // Get the updated report data from the form
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // Update the report in the database
    $sql = "UPDATE complain_table SET title = '$title', description = '$description' WHERE id = $id";
    mysqli_query($conn, $sql);

    // Close the database connection
    mysqli_close($conn);

    // Redirect to the dashboard
    header("Location: adminDash.php");
    exit();
}

// Check if the ID parameter is set
if (isset($_GET['id'])) {

    $id = $_GET['id'];

    // Fetch the report data from the database
    $sql = "SELECT * FROM complain_table WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $report = mysqli_fetch_assoc($result);

    // Close the database connection
    mysqli_close($conn);
}
?>
<style>

form {
display: flex;
flex-direction: column;
align-items: center;
}

input[type="text"],
textarea {
padding: 10px;
border: 8px solid #ccc;
border-radius: 4px;
margin-bottom: 10px;
width: 30%;
}

label {
font-weight: bold;
}

button[type="submit"] {
background-color: #4CAF50;
color: #fff;
padding: 10px 20px;
border: none;
border-radius: 4px;
cursor: pointer;
font-size: 16px;
}

button[type="submit"]:hover {
background-color: #3e8e41;
}
</style>



<form method="POST" >
    <input type="hidden" name="id" value="<?php echo $id; ?>"> <br>
    <label for="title">Title:</label>
    <input type="text" name="title" value="<?php echo $report['title']; ?>"> <br>
    <label for="description">Description:</label>
    <textarea name="description"><?php echo $report['description']; ?></textarea>
    <button type="submit" name="submit">Save</button>
</form>
