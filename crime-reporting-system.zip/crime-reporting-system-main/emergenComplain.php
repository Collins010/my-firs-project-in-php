<?php
require_once 'db_connection.php';
// Get user input from the HTML form
$name = $_POST['name'];
$email = $_POST['email'];
$phone_number = $_POST['phone_number'];
$location = $_POST['location'];
$title = $_POST['title'];
$description = $_POST['description'];
$image = $_POST['image'];

// Prepare SQL statement to insert user details into the database
$sql = "INSERT INTO emergency_table (name, email, phone_number, location,title, description,image) VALUES ('$name','$email', '$phone_number','$location','$title','$description','$image')";

// Execute SQL statement
if ($conn->query($sql) === TRUE) {
    echo "Your emergency Complain has being successfully Sent";
} else {
    echo "Error sending your emergency complaint: " . $sql . "<br>" . $conn->error;
}

// Close database connection
$conn->close();
?>
<br> <br>
<a href="login.html">back</a>

