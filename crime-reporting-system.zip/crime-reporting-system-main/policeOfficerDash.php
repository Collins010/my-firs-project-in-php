<style>
    body {
        font-family: Arial, sans-serif;
        background-image: url("police11.jpg");
        font-size: 16px;
        color: #333;
    }
    @media screen and (max-width: 768px) {
        body {
            font-size: 14px;
        }
    }

    @media screen and (max-width: 480px) {
        body {
            font-size: 12px;
        }
    }


    .police-officer-dashboard {
        display: flex;
        margin: 50px auto;
        max-width: 1200px;
    }

    .menu {
        width: 200px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        padding: 20px;
    }

    .menu ul {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .menu li {
        margin-bottom: 10px;
    }

    .menu a {
        display: block;
        padding: 10px;
        color: #555;
        text-decoration: none;
    }

    .menu a:hover {
        background-color: #f2f2f2;
    }

    .content {
        flex: 1;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        padding: 20px;
    }

    h2 {
        margin-top: 0;
        margin-bottom: 20px;
    }
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Police Officer Dashboard</title>
</head>
<body>
<div class="police-officer-dashboard">
    <div class="menu">
        <ul>
            <li><a href="assignCitizen.php">Assigned Complaints</a></li>
            <li><a href="viewEmergenComplain.php">Emergency Complaints</a></li>
            <li><a href="login.html">Logout</a> </li>
        </ul>
    </div>
    <div class="content">
        <h2>Police Officer Dashboard</h2>
        <!-- Add content here -->
    </div>
</div>
</body>
</html>
