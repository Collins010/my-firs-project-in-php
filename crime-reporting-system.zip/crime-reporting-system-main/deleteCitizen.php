<?php
require_once 'db_connection.php';
// Check if the delete link has been clicked
if (isset($_GET['username'])) {
    // Get the username of the record to delete
    $username = $_GET['username'];


    // Delete the record from the database
    $sql = "DELETE FROM users_table WHERE username = '$username'";
    mysqli_query($conn, $sql);

    // Close the database connection
    mysqli_close($conn);

    // Redirect to the dashboard
    header("Location: citizen.php");
    exit();
}
else{
        echo "Error:". $conn->error;
}
?>

