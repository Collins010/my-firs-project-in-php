<?php
require_once 'db_connection.php';
// Get user input from the HTML form
$username = $_POST['username'];
$phone = $_POST['phone'];
$fullname = $_POST['fullname'];
$password = $_POST['password'];
$email = $_POST['email'];



// Prepare SQL statement to insert user details into the database
$sql = "INSERT INTO police_Table (username, phone, fullname, password, email) VALUES ('$username', '$phone','$fullname','$password','$email')";

// Execute SQL statement
if ($conn->query($sql) === TRUE) {
    echo "Account created successfully";
    header('location: policeOfficerDash.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close database connection
$conn->close();
?>

