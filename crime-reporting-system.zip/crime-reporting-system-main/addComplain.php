<style>
    body {
        font-family: Arial, sans-serif;
        background-image: url("emergency.jpg");

    }
    @media screen and (max-width: 768px) {
        body {
            font-size: 14px;
        }
    }

    @media screen and (max-width: 480px) {
        body {
            font-size: 12px;
        }
    }

    .emergency-complaint {
        max-width: 1200px;
        margin: 50px auto;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        padding: 20px;
        width: 40%;
        height: 69%
    }

    h2 {
        margin-top: 0;
        margin-bottom: 20px;
        text-align: center;
    }

    input[type="text"], input[type="email"], textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: none;
        border-radius: 5px;
        background-color: #f2f2f2;
    }

    button {
        background-color: #4CAF50;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 10px;
        cursor: pointer;
        width: 100%;
        font-size: 16px;
    }

    button:hover {
        opacity: 0.8;
    }

    .message {
        margin-top: 20px;
        font-size: 14px;
        color: #666;
    }

    .message a {
        color: #4CAF50;
        text-decoration: none;
    }
    .copy{
        text-align: center;
    }

</style>
<!DOCTYPE html>
<html>
<head>
    <title>Add Complaint</title>
    <!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
</head>
<body>
<div class="emergency-complaint">
    <h2>Add Complaint</h2>
    <form class="emergency-complaint-form" method="post" action="addComplains.php">
        <input type="text" name="name" placeholder="Name"/>
        <input type="email" name="email" placeholder="Email"/>
        <input type="text" name="phone_number" placeholder="Phone Number"/>
        <input type="text" name="location" placeholder="Location"/>
        <input type="text" name="title" placeholder="title Of The Complain"/>
        <textarea name="description" placeholder="Description"></textarea>
        <label for="image"></label>
        <input type="file" id="image" name="image" required>
        <button>Submit</button>
        <p class="copy">Copyright &copy;20<?php echo date ('y');?> reserved</p>
    </form>
</div>
</body>
</html>
