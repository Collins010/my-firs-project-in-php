<style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #f5f5f5;
    }

    a {
        color: #f44336;
    }
    h1{
        text-align: center;
    }
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Crime Reporting System - View Citizens</title>

</head>
<body>
<div class="container">
    <h1>my complain details</h1>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>name</th>
            <th>email</th>
            <th>phoneNumber</th>
            <th>location</th>
            <th>title of the complain</th>
            <th>description</th>
            <th>images</th>
            <th>action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        require_once 'db_connection.php';
        // Create a MySQLi connection object

        // Execute a query to retrieve the list of citizens
        $sql = "SELECT * FROM complain_table ORDER BY name";
        $result = mysqli_query($conn, $sql);

        // Check if the query was successful
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        // Fetch the results and store them in an array
        $complains = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $complains[] = $row;
        }

        // Close the connection
        mysqli_close($conn);
        foreach ($complains as $complain):

            ?>
            <tr>
                <td><?php echo $complain['id']; ?></td>
                <td><?php echo $complain['name']; ?></td>
                <td><?php echo $complain['email']; ?></td>
                <td><?php echo $complain['phone_number']; ?></td>
                <td><?php echo $complain['location']; ?></td>
                <td><?php echo $complain['title']; ?></td>
                <td><?php echo $complain['description']; ?></td>
                <td><img src="data:image/png;base64,<?php echo base64_encode($complain['image']); ?>" width="100"></td>
                <td><a href="deleteComplainadmin.php?id=<?php echo $complain['id']; ?>">Delete</a></td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
</div>
</body>
</html>


