<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $admin_username = 'admin';
    $admin_password = 'admin';

    // Validate the username and password against the admin credentials
    if ($username === $admin_username && $password === $admin_password) {
        // If the credentials are valid, create a session for the admin
        $_SESSION['admin'] = true;
        header('Location: adminDash.php');
        exit;
    } else {
        // If the credentials are invalid, display an error message
        $error = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords"
          content="unique login form,leamug login form,boostrap login form,responsive login form,free css html login form,download login form">
    <meta name="author" content="leamug">
    <title>Admin  |  login</title>
    <link rel="stylesheet" href="adminLogin.css">
    <link href="css/style.css" rel="stylesheet" id="style">

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <link href="https://fonts.googleapis.com/css?family=Dancing+Script" rel="stylesheet">

    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-offset-5 col-md-4 text-center">
            <h1 class='text-white'>Admin -- login</h1>
            <div class="form-login"></br>
                <form method="post" action="">
                <h4>Login here!</h4>
                </br>
                <input type="text" name="username" id="username" required class="form-control input-sm chat-input" placeholder="username"/>
                </br></br>
                <input type="password" name="password" id="userpassword"  required class="form-control input-sm chat-input" placeholder="password"/>
                </br></br>
                <div class="wrapper">
                        <span class="group-btn">
                            <input type="submit" value="Login" class="btn btn-danger btn-md">
                        </span>
                </div>
                </form>

            </div>
        </div>
    </div>
    </br></br></br>


    </div>

</body>
</html>