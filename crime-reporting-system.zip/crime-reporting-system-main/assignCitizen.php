<!DOCTYPE html>
<html>
<head>
    <title>Crime Reporting System</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 20px;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
    </style>
</head>
<body>
<h1>assign police to complain</h1>
<table>
    <thead>
    <tr>
        <th>Complaint</th>
        <th>Assigned police</th>
    </tr>
    </thead>
    <tbody>
    <?php
			require_once 'db_connection.php';
			// Retrieve the list of citizens from the database
			$citizen_query = "SELECT username FROM police_table";
			$citizen_result = mysqli_query($conn, $citizen_query);

			// Retrieve the list of complaints from the database
			$complaint_query = "SELECT description FROM complain_table";
			$complaint_result = mysqli_query($conn, $complaint_query);

			// Assign a citizen to each complaint
			while ($complaint_row = mysqli_fetch_assoc($complaint_result)) {
			    // Select a random citizen
			    $citizen_row = mysqli_fetch_assoc($citizen_result);
			    $assignedCitizen = $citizen_row['username'];

			    // Assign the citizen to the complaint
			    echo "<tr><td>" . $complaint_row['description'] . "</td><td>" . $assignedCitizen . "</td></tr>";
    }

    // Close the database connection
    mysqli_close($conn);
    ?>
    </tbody>
</table>
</body>
</html>