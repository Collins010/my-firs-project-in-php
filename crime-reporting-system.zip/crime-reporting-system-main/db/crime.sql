-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2023 at 12:57 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crime`
--

-- --------------------------------------------------------

--
-- Table structure for table `complain_table`
--

CREATE TABLE `complain_table` (
  `name` varchar(20) NOT NULL,
  `email` varchar(12) NOT NULL,
  `phone_number` int(20) NOT NULL,
  `location` varchar(35) NOT NULL,
  `title` varchar(35) NOT NULL,
  `description` text NOT NULL,
  `image` longblob NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emergency_table`
--

CREATE TABLE `emergency_table` (
  `name` varchar(20) NOT NULL,
  `email` varchar(12) NOT NULL,
  `phone_number` int(20) NOT NULL,
  `location` varchar(35) NOT NULL,
  `title` varchar(35) NOT NULL,
  `description` text NOT NULL,
  `image` longblob NOT NULL,
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `police_table`
--

CREATE TABLE `police_table` (
  `username` varchar(20) NOT NULL,
  `phone` int(12) NOT NULL,
  `fullname` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_table`
--

CREATE TABLE `users_table` (
  `username` varchar(20) NOT NULL,
  `phone` int(12) NOT NULL,
  `fullname` varchar(20) NOT NULL,
  `password` int(11) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_table`
--

INSERT INTO `users_table` (`username`, `phone`, `fullname`, `password`, `email`) VALUES
('police', 2147483647, 'fon boris', 0, 'njiboris@gmail.com'),
('police', 2147483647, 'fon boris', 0, 'njicollins521@gmail.'),
('collines12', 2147483647, 'furu coollines nji', 0, 'njicollins521@gmail.'),
('paul123', 65874141, 'paul ', 0, 'paul@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complain_table`
--
ALTER TABLE `complain_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emergency_table`
--
ALTER TABLE `emergency_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complain_table`
--
ALTER TABLE `complain_table`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `emergency_table`
--
ALTER TABLE `emergency_table`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
