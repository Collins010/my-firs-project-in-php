<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
    }
    @media screen and (max-width: 768px) {
        body {
            font-size: 14px;
        }
    }

    @media screen and (max-width: 480px) {
        body {
            font-size: 12px;
        }
    }

    .complaint-details {
        max-width: 1200px;
        margin: 50px auto;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.3);
        padding: 20px;
    }

    h2 {
        margin-top: 0;
        margin-bottom: 20px;
    }
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Complaint Details</title>
    <!--<link rel="stylesheet" type="text/css" href="style.css"> -->
</head>
<body>
<div class="complaint-details">
    <h2>Complaint Details</h2>
    <!-- Add content here -->
</div>
</body>
</html>
