<?php
require_once 'db_connection.php';
// Get user input from the HTML form
$email = $_POST['email'];

// Prepare SQL statement to retrieve user details from the database
$sql = "SELECT * FROM users_table WHERE email='$email'";

// Execute SQL statement
$result = $conn->query($sql);

// Check if user exists
if ($result->num_rows == 1) {
    // User exists, so generate a new password and update the database
    $new_password = generateRandomString(8); // Generate a random string of length 8
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT); // Hash the new password
    $row = $result->fetch_assoc();
    $username = $row['username'];
    $sql = "UPDATE users_table SET password='$hashed_password' WHERE email='$email'";
    if ($conn->query($sql) === TRUE) {
        // Password updated successfully, so display the new password to the user
        echo "Your new password is<br>: $new_password\n\nPlease login with your new password and change it immediately.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // User does not exist, so display an error message
    echo "Invalid email address";
}

// Close database connection
$conn->close();

// Function to generate a random string
function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $characters_length = strlen($characters);
    $random_string = '';
    for ($i = 0; $i < $length; $i++) {
        $random_string .= $characters[rand(0, $characters_length - 1)];
    }
    return $random_string;
}
?>