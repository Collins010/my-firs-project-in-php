<style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: rgba(155, 213, 175, 0.2);
    }

    tr:hover {
        background-color: rgba(112, 40, 40, 0.44);
    }

    a {
        color: #f44336;
    }
    h1{
        text-align: center;
    }
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Crime Reporting System - View Citizens</title>

</head>
<body>
<div class="container">
    <h1>Police Station</h1>
    <table>
        <thead>
        <tr>
            <th>username</th>
            <th>phone</th>
            <th>fullname</th>
            <th>email</th>
            <th>action</th>
            <th>action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        require_once 'db_connection.php';
        // Create a MySQLi connection object

        // Execute a query to retrieve the list of citizens
        $sql = "SELECT * FROM police_table ORDER BY username";
        $result = mysqli_query($conn, $sql);

        // Check if the query was successful
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        // Fetch the results and store them in an array
        $polices = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $polices[] = $row;
        }

        // Close the connection
        mysqli_close($conn);
        foreach ($polices as $police):

            ?>
            <tr>
                <td><?php echo $police['username']; ?></td>
                <td><?php echo $police['phone']; ?></td>
                <td><?php echo $police['fullname']; ?></td>
                <td><?php echo $police['email']; ?></td>
                <td><a href="deletePolicE.php?username=<?php echo $police['username']; ?>">Delete</a></td>
                <td><a href="addPolice.php">add citizen</a> </td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
</div>
</body>
</html>
