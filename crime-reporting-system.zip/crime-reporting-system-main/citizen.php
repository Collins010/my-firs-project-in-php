<style>
table {
border-collapse: collapse;
width: 100%;
}

th, td {
padding: 8px;
text-align: left;
border-bottom: 1px solid #ddd;
}

th {
background-color: #f2f2f2;
}

tr:hover {
background-color: #f5f5f5;
}

a {
color: #f44336;
}
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Crime Reporting System - View Citizens</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h1>Citizens</h1>
    <table>
        <thead>
        <tr>
            <th>username</th>
            <th>phone</th>
            <th>fullname</th>
            <th>email</th>
            <th>action</th>
            <th>action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        require_once 'db_connection.php';
        // Create a MySQLi connection object

        // Execute a query to retrieve the list of citizens
        $sql = "SELECT * FROM users_table ORDER BY username";
        $result = mysqli_query($conn, $sql);

        // Check if the query was successful
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        // Fetch the results and store them in an array
        $citizens = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $citizens[] = $row;
        }

        // Close the connection
        mysqli_close($conn);
        foreach ($citizens as $citizen):

            ?>
            <tr>
                <td><?php echo $citizen['username']; ?></td>
                <td><?php echo $citizen['phone']; ?></td>
                <td><?php echo $citizen['fullname']; ?></td>
                <td><?php echo $citizen['email']; ?></td>
                <td><a href="deleteCitizen.php?username=<?php echo $citizen['username']; ?>">Delete</a></td>

                <td><a href="addCitizen.php">add citizen</a> </td>

            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
</div>
</body>
</html>