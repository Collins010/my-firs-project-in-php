<?php
require_once 'db_connection.php';
// Check if the delete link has been clicked
if (isset($_GET['id'])) {
    // Get the username of the record to delete
    $id = $_GET['id'];


    // Delete the record from the database
    $sql = "DELETE FROM complain_table WHERE id = $id";
    mysqli_query($conn, $sql);

    // Close the database connection
    mysqli_close($conn);

    // Redirect to the dashboard
    header("Location: viewComplainAdmin.php");
    exit();
}
else{
    echo "Error:". $conn->error;
}
?>



