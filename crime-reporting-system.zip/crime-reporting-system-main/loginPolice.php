<?php
require_once 'db_connection.php';
// Get user input from the HTML form
$username = $_POST['username'];
$password = $_POST['password'];
// Prepare SQL statement to retrieve user details from the database
$sql = "SELECT * FROM police_table WHERE username='$username' AND password='$password'";

// Execute SQL statement
$result = $conn->query($sql);

// Check if user exists and password is correct
if ($result->num_rows == 1) {
    // User exists and password is correct, so start a session
    session_start();
    $_SESSION['username'] = $username;
    $_SESSION['loggedin'] = true;
    // Redirect to the home page or some other secure page
    header('Location: policeOfficerDash.php');
} else {
    // User does not exist or password is incorrect, so display an error message
    echo "Invalid username or password";
}
// Close database connection
$conn->close();
?>