<style>
table {
border-collapse: collapse;
width: 100%;
}

th, td {
padding: 8px;
text-align: left;
border-bottom: 1px solid #ddd;
}

th {
background-color: #f2f2f2;
}

tr:hover {
background-color: #f5f5f5;
}

a {
color: #f44336;
}
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Crime Reporting System - View Citizens</title>

</head>
<body>
<div class="container">
    <h1>Emergency complain details</h1>
    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>name</th>
            <th>email</th>
            <th>phoneNumber</th>
            <th>location</th>
            <th>title Of the emergency complain</th>
            <th>description</th>
            <th>image</th>
            <th>action</th>
        </tr>
        </thead>
        <tbody>
        <?php
        require_once 'db_connection.php';
        // Create a MySQLi connection object

        // Execute a query to retrieve the list of citizens
        $sql = "SELECT * FROM emergency_table ORDER BY name";
        $result = mysqli_query($conn, $sql);


        // Check if the query was successful
        if (!$result) {
            die("Query failed: " . mysqli_error($conn));
        }

        // Fetch the results and store them in an array
        $emergens = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $emergens[] = $row;
        }

        // Close the connection
        mysqli_close($conn);
        foreach ($emergens as $emergen):

            ?>
            <tr>
                <td><?php echo $emergen['id']; ?></td>
                <td><?php echo $emergen['name']; ?></td>
                <td><?php echo $emergen['email']; ?></td>
                <td><?php echo $emergen['phone_number']; ?></td>
                <td><?php echo $emergen['location']; ?></td>
                <td><?php echo $emergen['title']; ?></td>
                <td><?php echo $emergen['description']; ?></td>
                <td><img src="data:image/png;base64,<?php echo base64_encode($emergen['image']); ?>" width="100"></td>

                <td><a href="deleteEmergenComplain.php?id=<?php echo $emergen['id']; ?>">Delete</a></td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
</div>
</body>
</html>


